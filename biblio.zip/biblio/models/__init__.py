# -*- coding: utf-8 -*-
from . import librairie
from . import biblio_res_partner